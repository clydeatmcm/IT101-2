package src.utils;

import java.io.*;
import java.util.Scanner;

public class FileCRUD2DArrayHandler {
    public static final int MAX_RECORDS = 100;
    public static final String DELIMITER = "###";

    public static String[][] readFile(String filename, int expectedFields) {
        String[][] records = new String[MAX_RECORDS][expectedFields];
        int count = 0;

        try (Scanner scanner = new Scanner(new File(filename))) {
            while (scanner.hasNextLine() && count < MAX_RECORDS) {
                String line = scanner.nextLine();
                String[] fields = line.split(DELIMITER);
                for (int i = 0; i < expectedFields && i < fields.length; i++) {
                    records[count][i] = fields[i];
                }
                count++;
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        return records;
    }

    public static void writeFile(String filename, String[][] records) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (int i = 0; i < records.length; i++) {
                if (records[i][0] == null) break;
                StringBuilder line = new StringBuilder();
                for (int j = 0; j < records[i].length; j++) {
                    if (j > 0) line.append(DELIMITER);
                    line.append(records[i][j]);
                }
                writer.write(line.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    public static int findIndexById(String[][] records, String id) {
        for (int i = 0; i < records.length; i++) {
            if (records[i][0] == null) break;
            if (records[i][0].equals(id)) return i;
        }
        return -1;
    }

    public static void addRecord(String[][] records, String[] newRecord) {
        for (int i = 0; i < records.length; i++) {
            if (records[i][0] == null) {
                for (int j = 0; j < newRecord.length; j++) {
                    records[i][j] = newRecord[j];
                }
                break;
            }
        }
    }

    public static void updateRecord(String[][] records, String id, String[] updatedRecord) {
        int index = findIndexById(records, id);
        if (index != -1) {
            for (int i = 0; i < updatedRecord.length; i++) {
                records[index][i] = updatedRecord[i];
            }
        }
    }

    public static void deleteRecord(String[][] records, String id) {
        int index = findIndexById(records, id);
        if (index != -1) {
            for (int i = index; i < records.length - 1; i++) {
                records[i] = records[i + 1];
                if (records[i][0] == null) break;
            }
            records[records.length - 1] = new String[records[0].length];
        }
    }
}