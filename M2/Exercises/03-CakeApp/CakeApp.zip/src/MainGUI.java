package src;

import src.utils.FileCRUD2DArrayHandler;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.io.File;
import java.util.Vector;

public class MainGUI {
    private static final String FILENAME = "data/Cakes.txt";
    private static final int FIELDS = 4;
    private static String[][] cakes;

    public static void main(String[] args) {
        cakes = FileCRUD2DArrayHandler.readFile(FILENAME, FIELDS);
        SwingUtilities.invokeLater(MainGUI::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Cake Catalogue App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        String[] columns = {"ID", "Name", "Price", "Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Load data
        for (String[] cake : cakes) {
            if (cake[0] == null) break;
            model.addRow(cake);
        }

        JTextField txtId = new JTextField(5);
        JTextField txtName = new JTextField(10);
        JTextField txtPrice = new JTextField(7);
        JTextField txtDate = new JTextField(10);
        JButton btnAdd = new JButton("Add");

        JPanel panel = new JPanel();
        panel.add(new JLabel("ID:"));
        panel.add(txtId);
        panel.add(new JLabel("Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Price:"));
        panel.add(txtPrice);
        panel.add(new JLabel("Date:"));
        panel.add(txtDate);
        panel.add(btnAdd);

        btnAdd.addActionListener(e -> {
            String[] newCake = {
                txtId.getText(), txtName.getText(), txtPrice.getText(), txtDate.getText()
            };
            FileCRUD2DArrayHandler.addRecord(cakes, newCake);
            FileCRUD2DArrayHandler.writeFile(FILENAME, cakes);
            model.addRow(newCake);
        });

        frame.getContentPane().add(panel, "North");
        frame.getContentPane().add(scrollPane, "Center");
        frame.setVisible(true);
    }
}